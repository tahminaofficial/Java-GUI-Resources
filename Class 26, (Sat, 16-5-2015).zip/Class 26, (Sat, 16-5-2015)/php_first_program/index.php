<?php
	/*
	$a = 10;
	$b = 5;
	
	$c = $a + $b;
	
	if($c == 15)
	{
		$state = true;
		echo $state;
	}
	else 
	{
		$state = false;
		echo $state;
	}
	echo "<br />";
	for($i = 0; $i < 10; $i++)
	{
		echo "This result is ". $c . "<br />";
	}
	*/
	
	//$fruitList = array("Mango", "Orange", "Licchi", "Apple");
	$fruitList = array();
	$fruitList["name"] = "DELL";
	$fruitList["age"] = ":)";
	
	$sizeIs = count($fruitList);
	
	
	/*
	for($i = 0; $i < $sizeIs; $i++)
	{
		echo $fruitList[$i]."<br />" ;
	}
	*/
	
	foreach($fruitList as $item)
		echo $item;
		
	//echo $fruitList[1];
?>



















