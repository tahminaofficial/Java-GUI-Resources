package com.example.customlistview;

import java.util.Arrays;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends Activity {

	ListView listExample;
	String []country;
	List<String>countryList;
	CustomAdapter adapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		listExample=(ListView) findViewById(R.id.listViewExample);
		
		country=getResources().getStringArray(R.array.country);
		
		countryList=Arrays.asList(country);
		
		adapter=new CustomAdapter(getApplicationContext(),countryList);
		listExample.setAdapter(adapter);
		
		
	}

}
