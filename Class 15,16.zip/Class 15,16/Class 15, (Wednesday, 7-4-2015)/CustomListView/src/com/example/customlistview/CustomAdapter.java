package com.example.customlistview;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class CustomAdapter extends BaseAdapter{

	LayoutInflater inFlater;
	Context context;
	List<String>countryList;
	
	public CustomAdapter(Context context, List<String>countryList) {
		// TODO Auto-generated constructor stub
		this.context=context;
		this.countryList=countryList;
		inFlater=(LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return countryList.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		Toast.makeText(context, "getView="+position, Toast.LENGTH_SHORT).show();
		ViewHolder holder=null;
		if(convertView==null)
		{
			convertView=inFlater.inflate(R.layout.item, null);
			
			holder=new ViewHolder();
			
			holder.textView=(TextView) convertView.findViewById(R.id.textViewAnimal);
//			textView.setText(countryList.get(position));
			convertView.setTag(holder);
			
		}
		else
		{
//			TextView textView=(TextView) convertView.findViewById(R.id.textViewAnimal);
//			textView.setText(countryList.get(position));
			holder=(ViewHolder) convertView.getTag();
		}
		holder.textView.setText(countryList.get(position));
		return convertView;
	}
	
	
	public static class ViewHolder
	{
		public TextView textView;
	}

}
