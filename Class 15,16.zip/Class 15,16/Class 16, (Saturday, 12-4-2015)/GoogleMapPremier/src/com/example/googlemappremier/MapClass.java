package com.example.googlemappremier;

import android.app.Dialog;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.location.LocationClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class MapClass extends FragmentActivity implements GooglePlayServicesClient.ConnectionCallbacks,GooglePlayServicesClient.OnConnectionFailedListener,LocationListener{
	
	GoogleMap map;
	Marker marker,myMarker;
	LatLng loc,myLoc;
	double lat,myLat,lon,myLon;
	Button direction;
	
	LocationClient locationClient;
	
	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		setContentView(R.layout.maps_layout);
		direction=(Button)findViewById(R.id.button1);
		
		
		direction.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				PolylineOptions line=new PolylineOptions().add(loc,myLoc).width(5).color(Color.RED);
				map.addPolyline(line);
			}
		});
		
		
		if(isMapAvailable())
		{
			try
			{
				map=((SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.map)).getMap();
				if(map==null)
				{
					Toast.makeText(getApplicationContext(), "Map is not initialized", Toast.LENGTH_LONG).show();
				}
				else
				{
					map.setMyLocationEnabled(true);
					lat = 22.368025;
	    			lon =91.849106;
	    			loc=new LatLng(lat, lon);
	    			marker=map.addMarker(new MarkerOptions().position(loc).title("Chittagong").snippet("A nice city"));
	    			marker.setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN));
	    			//map.moveCamera(CameraUpdateFactory.newLatLngZoom(loc, 11.0f));
	    			//marker.showInfoWindow();
	    			locationClient=new LocationClient(MapClass.this, MapClass.this, MapClass.this);
	    			
	    			
				}
			}
			catch(Exception e)
			{
				Toast.makeText(getApplicationContext(), ""+e, Toast.LENGTH_LONG).show();
			}
		}
		
		
		map.setOnMarkerClickListener(new OnMarkerClickListener() {
			
			@Override
			public boolean onMarkerClick(Marker marker) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), marker.getTitle()+" marker is clicked", Toast.LENGTH_LONG).show();
				return true;
			}
		});
		
		map.setOnInfoWindowClickListener(new OnInfoWindowClickListener() {
			
			@Override
			public void onInfoWindowClick(Marker marker) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), marker.getTitle()+" info window is clicked", Toast.LENGTH_LONG).show();
			}
		});
		
		
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		locationClient.connect();
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		locationClient.disconnect();
	}
	
	public boolean isMapAvailable()
	{
		int resultCode=GooglePlayServicesUtil.isGooglePlayServicesAvailable(MapClass.this);
		if(ConnectionResult.SUCCESS==resultCode) return true;
		else if(GooglePlayServicesUtil.isUserRecoverableError(resultCode))
		{
			Dialog dialog=GooglePlayServicesUtil.getErrorDialog(resultCode, MapClass.this, 1);
			dialog.show();
		}
		else
		{
			Toast.makeText(getApplicationContext(), "Google Maps API v2 is not supported in your device", Toast.LENGTH_LONG).show();
			finish();
		}
		return false;
	}


	@Override
	public void onLocationChanged(Location arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onProviderDisabled(String arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onProviderEnabled(String arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onConnectionFailed(ConnectionResult arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onConnected(Bundle arg0) {
		// TODO Auto-generated method stub
		Location location=locationClient.getLastLocation();
		try
		{
			myLat=location.getLatitude();
			myLon=location.getLongitude();
			myLoc=new LatLng(myLat, myLon);
			myMarker=map.addMarker(new MarkerOptions().position(myLoc).title("You are here").snippet("Click here"));
			myMarker.setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE));
			myMarker.showInfoWindow();
			map.moveCamera(CameraUpdateFactory.newLatLngZoom(myLoc, 12.0f));
		}
		catch(Exception e)
		{
			Toast.makeText(getApplicationContext(), "Location not found", Toast.LENGTH_LONG).show();
		}
	}


	@Override
	public void onDisconnected() {
		// TODO Auto-generated method stub
		
	}
	
	

}
