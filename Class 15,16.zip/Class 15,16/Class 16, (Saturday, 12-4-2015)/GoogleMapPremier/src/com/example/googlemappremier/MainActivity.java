package com.example.googlemappremier;

import java.util.List;
import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	Button showMap,btnDistance,btnAddress;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		showMap=(Button)findViewById(R.id.button1);
		btnDistance=(Button)findViewById(R.id.button2);
		btnAddress=(Button)findViewById(R.id.button3);
		
		showMap.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent in=new Intent(MainActivity.this,MapClass.class);
				startActivity(in);
			}
		});
		
		
		btnDistance.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				double lat1 = 22.368025;
				double lon1 = 91.849106;
				double lat2 = 22.351451;
				double lon2 =  91.852068;
				
				float[] results=new float[1];
				
				Location.distanceBetween(lat1, lon1, lat2, lon2, results);
				double distance=(results[0]/1000);
				Toast.makeText(getApplicationContext(), "Distance: "+distance+"km", Toast.LENGTH_LONG).show();
				
			}
		});
		
		
		btnAddress.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Geocoder gcd=new Geocoder(MainActivity.this, Locale.getDefault());
				List<Address> addresses=null;
				Address addr=null;
				double lat1 = 22.368025;
				double lon1 = 91.849106;
				try
				{
					addresses=gcd.getFromLocation(lat1, lon1, 1);
					if(addresses.size()>0)
					{
						addr=addresses.get(0);
						String area="Address is: ";
						if(addr.getMaxAddressLineIndex()>0)
						{
							area+=addr.getAddressLine(0);
						}
						area+=", "+addr.getLocality()+", "+addr.getCountryName();
						Toast.makeText(getApplicationContext(), area, Toast.LENGTH_LONG).show();
					}
				}
				catch(Exception e)
				{
					Toast.makeText(getApplicationContext(), "Address not found", Toast.LENGTH_LONG).show();
				}
			}
		});
		
		
	}


}
