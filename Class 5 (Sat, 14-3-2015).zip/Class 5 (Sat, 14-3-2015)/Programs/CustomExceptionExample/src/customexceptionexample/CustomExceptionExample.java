/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package customexceptionexample;

/**
 *
 * @author Shanta
 */
public class CustomExceptionExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            compute(12);
        } catch (Exception e) {
            System.out.println("Exceotion caught: "+e);
        }
    }
    
    public static void compute(int a) throws GreaterThanTenException
    {
        if(a>10)
        {
            throw new GreaterThanTenException("It is greater than ten");
        }
    }
}
