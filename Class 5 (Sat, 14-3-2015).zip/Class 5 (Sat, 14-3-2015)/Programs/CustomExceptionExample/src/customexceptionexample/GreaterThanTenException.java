/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package customexceptionexample;

/**
 *
 * @author Shanta
 */
public class GreaterThanTenException extends Exception{
    
    public String x;

    public GreaterThanTenException(String x) {
        this.x = "GreaterThanTenException: "+x;
    }

    @Override
    public String toString() {
        return x;
    }
    
    
    
    
    
    
}
