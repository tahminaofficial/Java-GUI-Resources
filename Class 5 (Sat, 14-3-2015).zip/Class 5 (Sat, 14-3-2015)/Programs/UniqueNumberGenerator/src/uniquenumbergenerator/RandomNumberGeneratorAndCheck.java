/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uniquenumbergenerator;

/**
 *
 * @author Blue
 */
public class RandomNumberGeneratorAndCheck {

    private double number[] = new double[10];
    int flag = 0;

    public RandomNumberGeneratorAndCheck() {
        setNumber();
    }

    public double[] getNumber() {
        return number;
    }

    private void setNumber() {

        while (flag < 10) {
            double tempNumber = Math.random();
            for (int i = 0; i < flag; i++) {

                if (tempNumber == number[i]) {
                    setNumber();
                }
            }
            number[flag] = tempNumber;
            flag++;
        }

    }

}
