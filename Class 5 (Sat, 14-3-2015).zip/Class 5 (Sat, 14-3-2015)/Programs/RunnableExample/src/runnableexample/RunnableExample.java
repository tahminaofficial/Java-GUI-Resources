/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package runnableexample;

/**
 *
 * @author Shanta
 */
public class RunnableExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MyThread thread1= new MyThread("First Thread");
        MyThread thread2= new MyThread("Second Thread");
        
    }
}
