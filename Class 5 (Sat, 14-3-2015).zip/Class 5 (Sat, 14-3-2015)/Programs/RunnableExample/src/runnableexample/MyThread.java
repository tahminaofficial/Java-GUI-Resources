/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package runnableexample;

/**
 *
 * @author Shanta
 */
public class MyThread  implements Runnable{
    Thread thread;
    

    public MyThread(String x) {
        thread= new Thread(this,x);
        if(x.equals("First Thread"))
        {
            thread.setPriority(Thread.MAX_PRIORITY);
        }
        else
        {
            thread.setPriority(Thread.MIN_PRIORITY);
        }
        
        thread.start();
    }
    
    

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(Thread.currentThread().getName()+": "+(i+1));
            try {
                thread.sleep(1000);
            } catch (InterruptedException ex) {
                
            }
        }
    }
    
}
