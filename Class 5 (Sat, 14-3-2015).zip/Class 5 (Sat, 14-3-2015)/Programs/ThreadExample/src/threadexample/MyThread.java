/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package threadexample;

/**
 *
 * @author Shanta
 */
public class MyThread extends Thread{

    public MyThread(String x) {
        super(x);
    }

    @Override
    public void run() {
        System.out.println("Current Thread: "+Thread.currentThread().getName());
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
        }
        System.out.println("After Sleep mode");
        
    }
    
    
    
    
}
