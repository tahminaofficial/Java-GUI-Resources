/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package threadexample;

/**
 *
 * @author Shanta
 */
public class ThreadExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Initial thread: "+Thread.currentThread().getName());
        MyThread thread= new MyThread("User created thread");
        thread.start();
    }
}
