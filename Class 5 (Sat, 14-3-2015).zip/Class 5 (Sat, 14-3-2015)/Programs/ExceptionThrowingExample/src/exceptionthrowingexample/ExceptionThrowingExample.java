/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionthrowingexample;

import java.util.Scanner;

/**
 *
 * @author Shanta
 */
public class ExceptionThrowingExample {

    /**0
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter a value: ");
        int number = scan.nextInt();

        try {
            compute(number);
        } catch (Exception e) {
            System.out.println("Caught exception: " + e);
        }
    }

    public static void compute(int a) throws ArithmeticException {
//        if(a==0)
//        {
//            throw new ArithmeticException("Divided by zero");
//        }
//        else
//        {
//            int b=10/a;
//            System.out.println("Value: "+b);
//        }

        int b = 10 / a;
        System.out.println("Value: " + b);

    }
}
