<?php

	error_reporting(0);
	$link = mysql_connect("localhost","root","");
	
	$con = mysql_select_db("json_parser", $link);
	
	if(!$con)
	{
		echo mysql_error();
	}
	else
	{
		echo "Ha Ha Ha <br />";
	}

?>