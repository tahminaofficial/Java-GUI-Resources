<?php
	include("connect.php");
	$db_query = mysql_query("SELECT * FROM info ORDER BY id ASC");
?>	
<?php
	$response = array();
	$response["product"] = array();
	
	if(mysql_num_rows($db_query) > 0)
	{
		while($row = mysql_fetch_array($db_query))
		{
			$product=array();
			$product["id"] = $row["id"];
			$product["name"] = $row["name"];
			$product["year"] = $row["year"];
			//echo $row["name"]."<br />";
			
			array_push($response["product"],$product);
		}
		
		$response["success"] = 1;
		echo json_encode($response);
	}
	else
		$response["success"] = 0;
?>
	<table>
		<tr>
			<th>ID</th>
			<th>Name</th>
			<th>Year</th>
		</tr>
		
<?php	
		$db_query = mysql_query("SELECT * FROM info  ORDER BY id ASC");
		while($db_fetch = mysql_fetch_assoc($db_query))
		{
			$id = $db_fetch['id'];
			$name = $db_fetch['name'];
			$year = $db_fetch['year'];
?>
		
			<tr>
				<td><?php echo $id;?></td>
				<td><?php echo $name;?></td>
				<td><?php echo $year;?></td>
			</tr>
		
<?php
	}
?>

	</table>
