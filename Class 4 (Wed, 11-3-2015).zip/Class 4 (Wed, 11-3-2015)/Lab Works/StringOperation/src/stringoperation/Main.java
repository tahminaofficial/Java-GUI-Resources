/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package stringoperation;

/**
 *
 * @author lab
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String x = "Premier University";
        String y = new String("Premier University");

        System.out.println(x);
        System.out.println(y);

        if (x.equals(y)) {
            System.out.println("x equals to y");
        } else {
            System.out.println("x is not equal to y");
        }

        System.out.println("x concated with y= " + x + y);

        System.out.println("x in lowercase= " + x.toLowerCase());
        System.out.println("y in uppercase= " + y.toUpperCase());

        System.out.println(x.substring(8));
        System.out.println(x.subSequence(0, 7));

//        regionMatches(starting index of String x,
//        other String y that would be matched with region of String x,
//                starting index of String y,
//                length treated as number of characters in two regions)
        if (x.regionMatches(1, y, 2, 5)) {
            System.out.println("region same");
        } else {
            System.out.println("region not same");
        }

    }
}
