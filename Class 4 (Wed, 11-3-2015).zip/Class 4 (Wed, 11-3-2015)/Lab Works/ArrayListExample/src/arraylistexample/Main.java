/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package arraylistexample;

import java.util.ArrayList;

/**
 *
 * @author lab
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ArrayList a1= new ArrayList();// Array list without type 
        
        ArrayList <Integer> a2= new ArrayList<Integer>();// Array list with integer type 
        a2.add(1);
        a2.add(2);
        System.out.println("Contents of a2= "+a2);
        
        System.out.println("Initial size: "+a1.size());
        a1.add("A");
        a1.add("B");
        a1.add("C");
        a1.add("D");
        a1.add(1);
        
        System.out.println("New size: "+a1.size());
        
        System.out.println("Cantents of ArrayList a1: "+a1);
        
        a1.add(2, "B2");
        System.out.println("Cantents of ArrayList a1: "+a1);
        
        a1.remove(5);
        System.out.println("Cantents of ArrayList a1: "+a1);
        
        a1.add("C");
        System.out.println("Cantents of ArrayList a1: "+a1);
        
        a1.remove("C");
        System.out.println("Cantents of ArrayList a1: "+a1);
        
    }

}
