/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package staticexample;

/**
 *
 * @author lab
 */
public class NewClass {
    int x=0;
    static int y=0;

}
