/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package staticexample;

/**
 *
 * @author lab
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        NewClass obj1= new NewClass();
        NewClass obj2= new NewClass();
        
        obj1.x++;
        obj2.x++;
        
        obj1.y++;
        obj2.y++;
        
        System.out.println("obj1.x= "+obj1.x);
        System.out.println("obj2.x= "+obj2.x);
        System.out.println("obj1.y= "+obj1.y);
        System.out.println("obj2.y= "+obj1.y);
    }

}
