/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hashmapexample;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author lab
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<String> a1= new ArrayList<String>();
        a1.add("A");
        a1.add("B");
        a1.add("C");
        
        ArrayList<String> a2= new ArrayList<String>();
        a2.add("Hello");
        a2.add("World");
        
        ArrayList<Integer> a3= new ArrayList<Integer>();
        a3.add(1);
        a3.add(2);
        
        
        HashMap<String,ArrayList<String>> value= new HashMap<String, ArrayList<String>>();
        value.put("alphabet", a1);
        value.put("greeting", a2);
        
        HashMap<String, ArrayList> value2= new HashMap<String, ArrayList>();
        value2.put("alphabet", a1);
        value2.put("greeting", a2);
        value2.put("Integer", a3);
        
        
        ArrayList<String> alphabet= new ArrayList<String>();
        ArrayList<String> greeting= new ArrayList<String>();
        
        alphabet=value.get("alphabet");
        greeting=value.get("greeting");
        
        System.out.println("Alphabet= "+alphabet);
        System.out.println("Greeting= "+greeting);
        
    }

}
