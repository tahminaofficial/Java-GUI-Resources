/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionexample;

/**
 *
 * @author lab
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            int a = 5 / 0;
            System.out.println(a);
        } catch (Exception e) {
            System.out.println("Catched Exception: " + e);

        } finally {
            System.out.println("This is finally block");
        }
        System.out.println("After try catch block");


//        try {
//            int a = 5 / 0;
//            System.out.println(a);
//        } catch (ArithmeticException e) {
//            System.out.println("Arithmatic Exception Catched: " + e);
//        }
//        catch(ArrayIndexOutOfBoundsException e)
//        {
//            System.out.println("ArrayIndexOutOfBoundsException Catched: " + e);
//        }
//        System.out.println("After try catch block");
    }
}
