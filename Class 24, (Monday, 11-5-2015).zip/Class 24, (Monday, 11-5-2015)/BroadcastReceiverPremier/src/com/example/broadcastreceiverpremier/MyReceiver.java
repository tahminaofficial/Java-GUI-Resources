package com.example.broadcastreceiverpremier;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;

public class MyReceiver extends BroadcastReceiver{

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		
		
		if(intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED"))
		{
			Bundle bundle=intent.getExtras();
			if(bundle!=null)
			{
				SmsMessage[] allMessages=null;
				String number=null;
				String message="";
				Object[] objects=(Object[])bundle.get("pdus");
				allMessages=new SmsMessage[objects.length];
				for(int i=0;i<objects.length;i++)
				{
					allMessages[i]=SmsMessage.createFromPdu((byte[])objects[i]);
					if(number==null) number=allMessages[i].getOriginatingAddress();
					message+=allMessages[i].getMessageBody();
				}
				SmsManager manager=SmsManager.getDefault();
				manager.sendTextMessage(number, null,message, null, null);
				
				Intent in=new Intent(context,MainActivity.class);
				in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startActivity(in);
				
			}
		}
		
	}

}
