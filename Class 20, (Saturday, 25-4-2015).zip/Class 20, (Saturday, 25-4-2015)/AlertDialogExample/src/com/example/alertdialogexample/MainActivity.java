package com.example.alertdialogexample;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	Button simple,single,multi,custom;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		simple=(Button)findViewById(R.id.button1);
		single=(Button)findViewById(R.id.button2);
		multi=(Button)findViewById(R.id.button3);
		custom=(Button)findViewById(R.id.button4);
		
		simple.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
				builder.setTitle("Simple Dialog");
				builder.setIcon(R.drawable.ic_launcher);
				builder.setMessage("This is a simple dialog. Click any button");
				builder.setCancelable(false);
				
				builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						Toast.makeText(getApplicationContext(), "Ok button is clicked", Toast.LENGTH_LONG).show();
						
					}
				});
				builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						Toast.makeText(getApplicationContext(), "Cancel button is clicked", Toast.LENGTH_LONG).show();
					}
				});
				
				AlertDialog simpleDialog=builder.create();
				simpleDialog.show();
				
			}
		});
		
		single.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
				builder.setTitle("Item Dialog");
				builder.setIcon(R.drawable.ic_launcher);
				builder.setCancelable(false);
				
				final String[] items={"Red","Green","Blue","White"};
				
				builder.setItems(items, new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface arg0, int position) {
						// TODO Auto-generated method stub
						String item=items[position];
						Toast.makeText(getApplicationContext(), item+" is clicked", Toast.LENGTH_LONG).show();
					}
				});
				
				builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						Toast.makeText(getApplicationContext(), "Dialog is canceled", Toast.LENGTH_LONG).show();
					}
				});
				
				AlertDialog itemDialog=builder.create();
				itemDialog.show();
				
				
			}
		});
		
		multi.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
				builder.setTitle("Multichoice Item Dialog");
				builder.setIcon(R.drawable.ic_launcher);
				builder.setCancelable(false);
				
				final String[] items={"Red","Green","Blue","White"};
				
				boolean[] status={false,true,true,false};
				
				final ArrayList<String> selected=new ArrayList<String>();
				selected.add(items[1]);
				selected.add(items[2]);
				
				builder.setMultiChoiceItems(items,status, new DialogInterface.OnMultiChoiceClickListener() {
					
					@Override
					public void onClick(DialogInterface arg0, int pos, boolean checked) {
						// TODO Auto-generated method stub
						if(checked) selected.add(items[pos]);
						else selected.remove(items[pos]);
					}
				});
				
				builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						String text="Selected items:";
						for(int i=0;i<selected.size();i++)
						{
							text+=" "+selected.get(i);
						}
						Toast.makeText(getApplicationContext(), text, Toast.LENGTH_LONG).show();
					}
				});
				
				AlertDialog dialog=builder.create();
				dialog.show();
				
				
			}
		});
		
		custom.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				LayoutInflater inflater=LayoutInflater.from(MainActivity.this);
				View view=inflater.inflate(R.layout.custom_layout, null);
				Button btnDialog=(Button)view.findViewById(R.id.btnDialog);
				
				AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
				builder.setView(view);
				builder.setCancelable(false);
				final AlertDialog dialog=builder.create();
				
				btnDialog.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View arg0) {
						// TODO Auto-generated method stub
						Toast.makeText(getApplicationContext(), "Button is clicked", Toast.LENGTH_LONG).show();
						dialog.cancel();
					}
				});
				
				dialog.show();
				
			}
		});
		
	}


}
