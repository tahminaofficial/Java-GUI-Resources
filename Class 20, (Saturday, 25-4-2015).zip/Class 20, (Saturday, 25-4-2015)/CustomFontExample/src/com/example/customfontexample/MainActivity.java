package com.example.customfontexample;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	TextView txt;
	EditText edt;
	Button btn;
	
	Typeface tf;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		txt=(TextView)findViewById(R.id.textView1);
		edt=(EditText)findViewById(R.id.editText1);
		btn=(Button)findViewById(R.id.button1);
		
		String text="ইহা বাংলা ফন্ট এর উদাহরণ";
		
		tf=Typeface.createFromAsset(this.getAssets(), "font/solaimanlipinormal.ttf");
		txt.setTypeface(tf);
		edt.setTypeface(tf);
		btn.setTypeface(tf);
		
		txt.setText(text);
		
		btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				String text1=edt.getText().toString();
				txt.setText(text1);
			}
		});
		
		
		
		
		
	}


}
