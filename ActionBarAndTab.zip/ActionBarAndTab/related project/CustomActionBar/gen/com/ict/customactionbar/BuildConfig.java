/** Automatically generated file. DO NOT MODIFY */
package com.ict.customactionbar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}