package com.example.tweenanimationexample;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class MainActivity extends Activity {

	TextView tvAnimate;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		tvAnimate=(TextView) findViewById(R.id.textView1);
		
		tvAnimate.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Animation rotate= AnimationUtils.loadAnimation(MainActivity.this, R.anim.rotate);
				tvAnimate.startAnimation(rotate);
				
			}
		});
	}

	

}
