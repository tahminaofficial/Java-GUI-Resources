package com.example.sharepreferenceexample;

import java.util.Random;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

	TextView tvHigh, tvCurrent;
	Button btnGenerate;

	SharedPreferences sharePreferenceRead;
	SharedPreferences.Editor sharedPreferenceEditor;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		tvCurrent = (TextView) findViewById(R.id.textViewCurrent);
		tvHigh = (TextView) findViewById(R.id.textViewHigh);
		btnGenerate = (Button) findViewById(R.id.button1);

		sharePreferenceRead = getSharedPreferences("game", MODE_PRIVATE);
		sharedPreferenceEditor = sharePreferenceRead.edit();
		int highScore = sharePreferenceRead.getInt("highScore", -1);// if
																	// highScore
																	// is not
																	// found
																	// then int
																	// highScore
																	// will be
																	// initialized
																	// by -1
																	// other
																	// wise it
																	// get the
																	// value
		tvHigh.setText("High Score: "+highScore);

		btnGenerate.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Random randomNumber= new Random();
				int score= randomNumber.nextInt(10000);
				tvCurrent.setText(score+"");
				int highScore = sharePreferenceRead.getInt("highScore", -1);
				
				if(score>highScore)
				{
					sharedPreferenceEditor.putInt("highScore", score);
					sharedPreferenceEditor.commit();
					highScore = sharePreferenceRead.getInt("highScore", -1);
					tvHigh.setText("High Score: "+highScore);
					
				}

			}
		});
	}

}
