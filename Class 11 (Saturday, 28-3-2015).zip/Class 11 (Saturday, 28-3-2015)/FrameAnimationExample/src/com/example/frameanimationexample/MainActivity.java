package com.example.frameanimationexample;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.drawable.AnimationDrawable;
import android.view.Menu;
import android.widget.ImageView;

public class MainActivity extends Activity {
	
	ImageView imageView;
	AnimationDrawable myAnimationDrawable;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		imageView=(ImageView) findViewById(R.id.imageView1);
		imageView.setImageResource(R.drawable.frameanimation);
		
		myAnimationDrawable=(AnimationDrawable) imageView.getDrawable();
		myAnimationDrawable.start();
	}

	

}
