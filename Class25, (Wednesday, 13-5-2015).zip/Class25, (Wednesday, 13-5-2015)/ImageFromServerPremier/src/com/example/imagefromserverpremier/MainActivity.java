package com.example.imagefromserverpremier;

import com.squareup.picasso.Picasso;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.view.Menu;
import android.widget.ImageView;

public class MainActivity extends Activity {
	
	ImageView img;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		img=(ImageView)findViewById(R.id.imageView1);
		
		ImageLoader loader=new ImageLoader();
		loader.execute();
		
		
	}

	
	class ImageLoader extends AsyncTask<String, String, String>
	{
		
		ProgressDialog dialog=new ProgressDialog(MainActivity.this);
		
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			dialog.setMessage("Image loading...");
			dialog.setCancelable(false);
			dialog.show();
		}
		
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			dialog.dismiss();
		}

		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub
			Picasso.with(MainActivity.this).load("http://upload.wikimedia.org/wikipedia/commons/5/59/Shakib-Al-Hasan-Face.jpg").into(img);
			return null;
		}
		
	}
	
	
	

}
