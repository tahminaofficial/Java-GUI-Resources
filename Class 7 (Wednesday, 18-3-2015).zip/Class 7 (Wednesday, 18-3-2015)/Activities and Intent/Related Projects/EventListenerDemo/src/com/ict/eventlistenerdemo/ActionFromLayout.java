package com.ict.eventlistenerdemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class ActionFromLayout extends Activity {

	
	Button button1,button2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.from_layout);
		Button button=(Button)findViewById(R.id.button1);
		 button1=(Button)findViewById(R.id.button1);
		 button2=(Button)findViewById(R.id.button2);
	
	}

	public void method1(View v)
	{
		
		Toast.makeText(getApplicationContext(), "You clicked button 1", Toast.LENGTH_LONG).show();
		
		return;
	}
	
	public void method2(View v)
	{
		
		Toast.makeText(getApplicationContext(), "You clicked button 2", Toast.LENGTH_LONG).show();
		
		return;
	}

}
