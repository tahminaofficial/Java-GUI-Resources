package com.ict.eventlistenerdemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class ListenerInterfaceActivity extends Activity implements OnClickListener {
Button button1,button2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listener_interface_layout);
		 button1=(Button)findViewById(R.id.button1);
		 button2=(Button)findViewById(R.id.button2);
			
		
		button1.setOnClickListener(this) ;
		button2.setOnClickListener(this) ;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		if(v.getId() == R.id.button1) 
	       {
	         // write your code here      
			
			Toast.makeText(getApplicationContext(), "You Clicked on Button 1", Toast.LENGTH_LONG).show();
	            return;
	       } 
	    if(v.getId() == R.id.button2) 

	           // write your code here         
	    	
	    	Toast.makeText(getApplicationContext(), "You Clicked on Button 2", Toast.LENGTH_LONG).show();
	            return;
	       }

		
	

}
