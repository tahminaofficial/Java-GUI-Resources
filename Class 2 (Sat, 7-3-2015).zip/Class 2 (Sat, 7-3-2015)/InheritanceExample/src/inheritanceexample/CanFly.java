/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritanceexample;

/**
 *
 * @author lab
 */
public class CanFly extends Bird{
    
    public CanFly()
    {
        System.out.println("This is CanFly Class");
    }
    
    public void canFlyThisBird()
    {
        System.out.println("This bird can fly");
    }
            

}
