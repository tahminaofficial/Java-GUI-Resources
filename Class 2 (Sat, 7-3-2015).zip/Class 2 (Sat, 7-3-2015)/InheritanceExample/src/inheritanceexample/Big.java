/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritanceexample;

/**
 *
 * @author lab
 */
public class Big extends CanFly{
    
    public Big()
    {
        System.out.println("This is Big Class");
    }
    
    public void theSizeIs()
    {
        System.out.println("I am a Big bird");
                
    }

}
