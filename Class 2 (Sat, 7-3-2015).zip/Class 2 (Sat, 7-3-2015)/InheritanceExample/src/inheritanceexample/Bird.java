/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritanceexample;

/**
 *
 * @author lab
 */
public class Bird {
    
    public Bird()
    {
        System.out.println("This is Bird Class");
    }
    
    public void hasWings()
    {
        System.out.println("It has two wings");
    }

}
