/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritanceexample;

/**
 *
 * @author lab
 */
public class White extends Big{
    
    public White()
    {
        System.out.println("This is White Class");
    }
    
    public void theColorIs()
    {
        System.out.println("My color is white");
                
    }

}
