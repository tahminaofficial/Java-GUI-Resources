/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package firstproject;

/**
 *
 * @author lab
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Man man1= new Man("Shuvo");
        System.out.println(man1.name);
        
    }

}
