/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package firstproject;

/**
 *
 * @author lab
 */
public class Man {
    public String name;
    
    public  Man(String name)
    {
        this.name=name;
        
    }
    
    public void getName(String name)
    {
        System.out.println(" My name is "+name);
    }
             

}
