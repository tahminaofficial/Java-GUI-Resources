/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package polymorphismexample;

/**
 *
 * @author lab
 */
public class OverLoadClass {
    
    public void method1()
    {
        System.out.println("This is method 1");
                
    }
    
    public void method1(int x)
    {
        System.out.println("This is method 2");
                
    }

}
