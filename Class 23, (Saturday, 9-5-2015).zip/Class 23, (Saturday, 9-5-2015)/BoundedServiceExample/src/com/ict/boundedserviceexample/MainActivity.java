package com.ict.boundedserviceexample;


import com.ict.boundedserviceexample.BoundService.MyLocalBinder;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	TextView text;
	Button btnTime,btnBind,btnUnbind;
	public static BoundService myService;
    public static boolean isBound = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		text=(TextView)findViewById(R.id.txt);
		btnTime=(Button)findViewById(R.id.btnTime);
		btnBind=(Button)findViewById(R.id.btnBind);
		btnUnbind=(Button)findViewById(R.id.btnUnbind);
        
        btnBind.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MainActivity.this, BoundService.class);
		        bindService(intent, myConnection, Context.BIND_AUTO_CREATE);
			}
		});
        
        btnUnbind.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				unbindService(myConnection);
				isBound=false;
				text.setText("Service is not bind now");
			}
		});
        
		btnTime.setOnClickListener(new OnClickListener() {	
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
		        if(isBound)
				{
		        String st=myService.myMethod();
		        st="Current time: "+st;
		        text.setText(st);
				}
				else
				{
					text.setText("Time can not be updated");
					Toast.makeText(getApplicationContext(),"Service is not bind", Toast.LENGTH_LONG).show();
				}
			}
		});
		
	}
	
	
	
	protected ServiceConnection myConnection=new ServiceConnection() {
		
		@Override
		public void onServiceDisconnected(ComponentName classname) {
			// TODO Auto-generated method stub
			 myService=null;
			 isBound = false;
			 text.setText("Service is not bind now");
		}
		
		@Override
		public void onServiceConnected(ComponentName classname, IBinder service) {
			// TODO Auto-generated method stub
			MyLocalBinder binder = (MyLocalBinder) service;
	        myService = binder.getService();
	        isBound = true;
	        text.setText("Service is bounded now");
		}
	};
	


}
