package com.ict.boundedserviceexample;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.widget.Toast;

public class BoundService extends Service {
	private final IBinder myBinder = new MyLocalBinder();

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		Toast.makeText(getApplicationContext(), "Service Binded", Toast.LENGTH_LONG).show();
		return myBinder;
	}
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		Toast.makeText(getApplicationContext(), "Service created", Toast.LENGTH_LONG).show();
	}
	
	@Override
	public boolean onUnbind(Intent intent) {
		// TODO Auto-generated method stub
		Toast.makeText(getApplicationContext(), "Service Unbinded", Toast.LENGTH_LONG).show();
		//MainActivity.isBound=false;
		//MainActivity.myService=null;
		return super.onUnbind(intent);
	}   
	
	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		Toast.makeText(getApplicationContext(), "Service Destroyed", Toast.LENGTH_LONG).show();
	}   
	
	public String myMethod() {
		Calendar c = Calendar.getInstance();
	    	SimpleDateFormat sdf = new SimpleDateFormat("dd:MMMM:yyyy HH:mm:ss a");
	    	//SimpleDateFormat sdf = new SimpleDateFormat("mm");	
	    		String time = sdf.format(c.getTime());
	    	//	int time1=Integer.valueOf(time);

		return time;
	}
	
	public class MyLocalBinder extends Binder {
		BoundService getService() {
            return BoundService.this;
        }
       }

}
