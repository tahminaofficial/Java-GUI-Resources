/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractclassexample;

/**
 *
 * @author lab
 */
public class NewClass extends AbstractClass {

    @Override
    public void method1() {
        System.out.println("This is method 1 from NewClass");
    }
}
