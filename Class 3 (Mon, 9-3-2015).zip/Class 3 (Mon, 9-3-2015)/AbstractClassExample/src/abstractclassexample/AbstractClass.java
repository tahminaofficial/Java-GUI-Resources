/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package abstractclassexample;

/**
 *
 * @author lab
 */
public abstract  class AbstractClass {

    public abstract void method1();
    
    public void method2()
    {
        System.out.println("This method 2 from AbstractClass");
    }
}
