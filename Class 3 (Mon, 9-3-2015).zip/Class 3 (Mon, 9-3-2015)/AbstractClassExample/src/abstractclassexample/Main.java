/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package abstractclassexample;

/**
 *
 * @author lab
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        NewClass obj1= new NewClass();
        
        obj1.method1();
        obj1.method2();
    }

}
