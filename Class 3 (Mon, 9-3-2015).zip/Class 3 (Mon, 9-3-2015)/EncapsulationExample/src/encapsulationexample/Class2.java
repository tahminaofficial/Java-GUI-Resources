/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package encapsulationexample;

import unknown.UnknownFriend;

/**
 *
 * @author lab
 */
public class Class2 extends UnknownFriend{
        
    public void getName()
    {
        name="Hello";
    }

}
