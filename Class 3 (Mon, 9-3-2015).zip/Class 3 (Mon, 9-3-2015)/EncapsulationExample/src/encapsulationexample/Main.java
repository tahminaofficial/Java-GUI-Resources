/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package encapsulationexample;

import unknown.UnknownFriend;

/**
 *
 * @author lab
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CloseFriend clsFrnd= new CloseFriend();
        clsFrnd.getStatus();
        
        UnknownFriend unknwFrnd= new UnknownFriend();
//        unknwFrnd.getStatus();
        
        
    }

}
