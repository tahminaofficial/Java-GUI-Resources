/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package encapsulationexample;

/**
 *
 * @author lab
 */
public class CloseFriend {
    
    protected  void getStatus()
    {
        System.out.println("Yes! Bangladesh Love u.");
    }
    

}
