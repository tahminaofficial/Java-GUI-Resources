/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package interfaceexample;

/**
 *
 * @author lab
 */
public class ClassB implements MouseListenerExample{
    
    public void onClick()
    {
        System.out.println("Program Shut Down");
    }

}
