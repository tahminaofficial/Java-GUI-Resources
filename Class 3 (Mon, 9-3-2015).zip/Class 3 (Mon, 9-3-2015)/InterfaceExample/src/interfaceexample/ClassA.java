/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package interfaceexample;

/**
 *
 * @author lab
 */
public class ClassA implements MouseListenerExample{

    public void onClick() {
        System.out.println("Hello world!!");
    }

}
