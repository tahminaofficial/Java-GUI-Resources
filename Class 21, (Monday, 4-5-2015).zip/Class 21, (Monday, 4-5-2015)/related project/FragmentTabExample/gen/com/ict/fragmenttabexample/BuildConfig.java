/** Automatically generated file. DO NOT MODIFY */
package com.ict.fragmenttabexample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}