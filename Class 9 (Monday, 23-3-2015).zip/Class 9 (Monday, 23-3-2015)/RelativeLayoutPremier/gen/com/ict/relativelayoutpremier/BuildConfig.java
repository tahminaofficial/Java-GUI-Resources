/** Automatically generated file. DO NOT MODIFY */
package com.ict.relativelayoutpremier;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}