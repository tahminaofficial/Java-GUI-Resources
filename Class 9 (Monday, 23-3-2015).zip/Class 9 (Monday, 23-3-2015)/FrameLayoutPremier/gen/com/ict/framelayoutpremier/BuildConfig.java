/** Automatically generated file. DO NOT MODIFY */
package com.ict.framelayoutpremier;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}