package com.example.googlemappremier;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

public class MapClass extends FragmentActivity {
	
	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		setContentView(R.layout.maps_layout);
	}

}
