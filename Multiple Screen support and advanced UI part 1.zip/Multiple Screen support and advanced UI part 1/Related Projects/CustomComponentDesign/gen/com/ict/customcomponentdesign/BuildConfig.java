/** Automatically generated file. DO NOT MODIFY */
package com.ict.customcomponentdesign;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}