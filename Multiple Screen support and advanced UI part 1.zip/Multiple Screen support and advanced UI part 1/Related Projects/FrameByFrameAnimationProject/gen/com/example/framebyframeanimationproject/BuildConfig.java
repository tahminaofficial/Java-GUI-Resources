/** Automatically generated file. DO NOT MODIFY */
package com.example.framebyframeanimationproject;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}